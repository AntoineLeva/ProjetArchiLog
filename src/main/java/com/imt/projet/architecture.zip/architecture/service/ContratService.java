package com.imt.projet.architecture.service;

import org.springframework.stereotype.Service;

@Service
public class ContratService {
}
