package com.imt.projet.architecture.model;

public class Contrat {
}
