package com.imt.projet.architecture.dto;

public class ContratDTO {
}
