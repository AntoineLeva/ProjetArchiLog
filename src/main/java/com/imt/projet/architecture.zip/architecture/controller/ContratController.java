package com.imt.projet.architecture.controller;

public class ContratController {
}
